package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class EntityPlayerSP extends EntityPlayer {
	public MovementInput movementInput;
	private Minecraft mc;
	public boolean Fly = false;
	public boolean FastFly = false;
	public boolean XRay = false;
	public boolean IM = false;
	public boolean Jesus = false;
	public boolean Coords = false;
	public boolean FC = false;
	public EntityPlayerSP(Minecraft var1, World var2, Session var3) {
		super(var2);
		this.mc = var1;
		if(var3 != null && var3.username != null && var3.username.length() > 0) {
			this.skinUrl = "http://www.minecraft.net/skin/" + var3.username + ".png";
			System.out.println("Loading texture " + this.skinUrl);
		}

		this.username = var3.username;
	}

	public void updateEntityActionState() {
		super.updateEntityActionState();
		this.moveStrafing = this.movementInput.moveStrafe;
		this.moveForward = this.movementInput.moveForward;
		this.isJumping = this.movementInput.jump;
	}

	public void onLivingUpdate() {
		this.movementInput.updatePlayerMoveState(this);
		if(this.movementInput.sneak && this.ySize < 0.2F) {
			this.ySize = 0.2F;
		}
		super.onLivingUpdate();
		if(this.Fly){
			this.onGround = false;
			this.motionX = 0.0D;
			this.motionY = 0.0D;
			this.motionZ = 0.0D;
			double d = this.rotationYaw + 90.0D;
			boolean flag = Keyboard.isKeyDown(this.mc.options.keyBindForward.keyCode);
			boolean flag1 = Keyboard.isKeyDown(this.mc.options.keyBindBack.keyCode);
			boolean flag2 = Keyboard.isKeyDown(this.mc.options.keyBindLeft.keyCode);
			boolean flag3 = Keyboard.isKeyDown(this.mc.options.keyBindRight.keyCode);
			if(flag) {
				if(flag2) {
					d -= 45.0D;
				} else if(flag3) {
					d += 45.0D;
				}
			} else if(flag1) {
				d += 180.0D;
				if(flag2) {
					d += 45.0D;
				} else if(flag3) {
					d -= 45.0D;
				}
			} else if(flag2) {
				d -= 90.0D;
			} else if(flag3) {
				d += 90.0D;
			}

			if(flag || flag2 || flag1 || flag3) {
				this.motionX = Math.cos(Math.toRadians(d)) / 5.0D;
				this.motionZ = Math.sin(Math.toRadians(d)) / 5.0D;
			}

			if(Keyboard.isKeyDown(this.mc.options.keyBindJump.keyCode)) {
				this.motionY = this.motionY + 0.2D;
			} else if(Keyboard.isKeyDown(this.mc.options.keyBindSneak.keyCode)) {
				this.motionY = this.motionY - 0.2D;
			}
			if(this.FastFly){
				this.motionX *= 2.5;
				this.motionY *= 2.5;
				this.motionZ *= 2.5;
			}
		}
		if(this.FC){
			this.Fly = true;
			this.noClip = true;
			this.mc.options.thirdPersonView = true;
			this.health = 20;
			((EntityClientPlayerMP)this).sendQueue.addToSendQueue(new Packet0KeepAlive());
		}
		else{
			this.noClip = false;
		}
	}

	public void resetPlayerKeyState() {
		this.movementInput.resetKeyState();
	}

	public void handleKeyPress(int var1, boolean var2) {
		this.movementInput.checkKeyForMovementInput(var1, var2);
	}

	public void writeEntityToNBT(NBTTagCompound var1) {
		super.writeEntityToNBT(var1);
		var1.setInteger("Score", this.score);
	}

	public void readEntityFromNBT(NBTTagCompound var1) {
		super.readEntityFromNBT(var1);
		this.score = var1.getInteger("Score");
	}

	public void displayGUIChest(IInventory var1) {
		this.mc.displayGuiScreen(new GuiChest(this.inventory, var1));
	}

	public void displayGUIEditSign(TileEntitySign var1) {
		this.mc.displayGuiScreen(new GuiEditSign(var1));
	}

	public void displayWorkbenchGUI() {
		this.mc.displayGuiScreen(new GuiCrafting(this.inventory));
	}

	public void displayGUIFurnace(TileEntityFurnace var1) {
		this.mc.displayGuiScreen(new GuiFurnace(this.inventory, var1));
	}

	public void attackEntity(Entity var1) {
		int var2 = this.inventory.getDamageVsEntity(var1);
		if(var2 > 0) {
			var1.attackEntityFrom(this, var2);
			ItemStack var3 = this.getCurrentEquippedItem();
			if(var3 != null && var1 instanceof EntityLiving) {
				var3.hitEntity((EntityLiving)var1);
				if(var3.stackSize <= 0) {
					var3.onItemDestroyedByUse(this);
					this.destroyCurrentEquippedItem();
				}
			}
		}

	}

	public void onItemPickup(Entity var1, int var2) {
		this.mc.effectRenderer.addEffect(new EntityPickupFX(this.mc.theWorld, var1, this, -0.5F));
	}

	public int getPlayerArmorValue() {
		return this.inventory.getTotalArmorValue();
	}

	public void interactWithEntity(Entity var1) {
		if(!var1.interact(this)) {
			ItemStack var2 = this.getCurrentEquippedItem();
			if(var2 != null && var1 instanceof EntityLiving) {
				var2.useItemOnEntity((EntityLiving)var1);
				if(var2.stackSize <= 0) {
					var2.onItemDestroyedByUse(this);
					this.destroyCurrentEquippedItem();
				}
			}

		}
	}

	public void sendChatMessage(String var1) {
	}

	public void onPlayerUpdate() {
	}

	public boolean isSneaking() {
		return this.movementInput.sneak;
	}
}
