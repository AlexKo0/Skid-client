package net.minecraft.src;

public class GuiSmallButton extends GuiButton {
	public GuiSmallButton(int var1, int var2, int var3, String var4) {
		super(var1, var2, var3, 150, 20, var4);
	}
}
