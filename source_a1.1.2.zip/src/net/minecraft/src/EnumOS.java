package net.minecraft.src;

public enum EnumOS {
	linux,
	solaris,
	windows,
	macos,
	unknown;
}
