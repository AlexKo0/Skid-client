package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Packet0KeepAlive extends Packet {
	public void processPacket(NetHandler var1) {
	}

	public void readPacketData(DataInputStream var1) {
	}

	public void writePacket(DataOutputStream var1) {
	}

	public int getPacketSize() {
		return 0;
	}
}
