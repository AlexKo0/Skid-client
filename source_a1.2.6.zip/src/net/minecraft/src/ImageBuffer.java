package net.minecraft.src;

import java.awt.image.BufferedImage;

public interface ImageBuffer {
	BufferedImage func_883_a(BufferedImage var1);
}
