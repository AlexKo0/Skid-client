package net.minecraft.src;

public class UnexpectedThrowable {
	public final String description;
	public final Throwable exception;

	public UnexpectedThrowable(String var1, Throwable var2) {
		this.description = var1;
		this.exception = var2;
	}
}
