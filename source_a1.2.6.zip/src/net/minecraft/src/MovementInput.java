package net.minecraft.src;

public class MovementInput {
	public float field_1174_a = 0.0F;
	public float field_1173_b = 0.0F;
	public boolean field_1177_c = false;
	public boolean field_1176_d = false;
	public boolean field_1175_e = false;

	public void func_797_a(EntityPlayer var1) {
	}

	public void func_798_a() {
	}

	public void func_796_a(int var1, boolean var2) {
	}
}
