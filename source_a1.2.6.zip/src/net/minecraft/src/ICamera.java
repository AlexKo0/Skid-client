package net.minecraft.src;

public interface ICamera {
	boolean func_342_a(AxisAlignedBB var1);

	void func_343_a(double var1, double var3, double var5);
}
