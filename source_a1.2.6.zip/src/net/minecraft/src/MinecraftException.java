package net.minecraft.src;

public class MinecraftException extends RuntimeException {
	public MinecraftException(String var1) {
		super(var1);
	}
}
