package net.minecraft.src;

public class MaterialLiquid extends Material {
	public boolean getIsLiquid() {
		return true;
	}

	public boolean func_880_c() {
		return false;
	}

	public boolean func_878_a() {
		return false;
	}
}
