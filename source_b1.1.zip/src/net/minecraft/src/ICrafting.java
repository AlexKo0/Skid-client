package net.minecraft.src;

public interface ICrafting {
	void func_20159_a(CraftingInventoryCB var1, int var2, ItemStack var3);

	void func_20158_a(CraftingInventoryCB var1, int var2, int var3);
}
