package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import java.util.List;

public class EntityPlayerSP extends EntityPlayer {
	public MovementInput movementInput;
	protected Minecraft mc;
	public int field_9373_b = 20;
	private boolean inPortal = false;
	public float timeInPortal;
	public float prevTimeInPortal;
	public boolean Fly = false;
	public boolean FastFly = false;
	public boolean KA = false;
	public boolean IM = false;
	public boolean FC = false;
	public boolean Coords = false;
	public EntityPlayerSP(Minecraft var1, World var2, Session var3, int var4) {
		super(var2);
		this.mc = var1;
		this.dimension = var4;
		if(var3 != null && var3.playerName != null && var3.playerName.length() > 0) {
			this.field_20047_bv = "http://www.minecraft.net/skin/" + var3.playerName + ".png";
			System.out.println("Loading texture " + this.field_20047_bv);
		}

		this.field_771_i = var3.playerName;
	}

	public void updatePlayerActionState() {
		super.updatePlayerActionState();
		this.moveStrafing = this.movementInput.moveStrafe;
		this.moveForward = this.movementInput.moveForward;
		this.isJumping = this.movementInput.jump;
	}
	private boolean canBeAttacked(Entity e){
		return e instanceof EntityMobs || e instanceof EntityAnimals || e instanceof EntityPlayer;
	}
	public void onLivingUpdate() {
		this.prevTimeInPortal = this.timeInPortal;
		if(this.inPortal) {
			if(this.timeInPortal == 0.0F) {
				this.mc.sndManager.func_337_a("portal.trigger", 1.0F, this.rand.nextFloat() * 0.4F + 0.8F);
			}

			this.timeInPortal += 0.0125F;
			if(this.timeInPortal >= 1.0F) {
				this.timeInPortal = 1.0F;
				this.field_9373_b = 10;
				this.mc.sndManager.func_337_a("portal.travel", 1.0F, this.rand.nextFloat() * 0.4F + 0.8F);
				this.mc.usePortal();
			}

			this.inPortal = false;
		} else {
			if(this.timeInPortal > 0.0F) {
				this.timeInPortal -= 0.05F;
			}

			if(this.timeInPortal < 0.0F) {
				this.timeInPortal = 0.0F;
			}
		}

		if(this.field_9373_b > 0) {
			--this.field_9373_b;
		}

		this.movementInput.updatePlayerMoveState(this);
		if(this.movementInput.sneak && this.field_9287_aY < 0.2F) {
			this.field_9287_aY = 0.2F;
		}

		if(this.Fly) {
			this.onGround = false;
			this.motionX = 0.0D;
			this.motionY = 0.0D;
			this.motionZ = 0.0D;
			double var1 = (double)this.rotationYaw + 90.0D;
			boolean var3 = Keyboard.isKeyDown(Keyboard.KEY_W);
			boolean var4 = Keyboard.isKeyDown(Keyboard.KEY_S);
			boolean var5 = Keyboard.isKeyDown(Keyboard.KEY_A);
			boolean var6 = Keyboard.isKeyDown(Keyboard.KEY_D);
			if(var3) {
				if(var5) {
					var1 -= 45.0D;
				} else if(var6) {
					var1 += 45.0D;
				}
			} else if(var4) {
				var1 += 180.0D;
				if(var5) {
					var1 += 45.0D;
				} else if(var6) {
					var1 -= 45.0D;
				}
			} else if(var5) {
				var1 -= 90.0D;
			} else if(var6) {
				var1 += 90.0D;
			}

			if(var3 || var5 || var4 || var6) {
				this.motionX = Math.cos(Math.toRadians(var1)) / 5.0D;
				this.motionZ = Math.sin(Math.toRadians(var1)) / 5.0D;
			}

			if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				this.motionY += 0.2D;
			} else if(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
				this.motionY -= 0.2D;
			}
			if(this.FastFly){
				this.motionX *= 2.5;
				this.motionY *= 2.5;
				this.motionZ *= 2.5;
			}
		}
		if(this.KA){
			List<?> list = mc.theWorld.getEntitiesWithinAABBExcludingEntity(mc.thePlayer, AxisAlignedBB.getBoundingBox(mc.thePlayer.posX - 10, mc.thePlayer.posY - 10, mc.thePlayer.posZ - 10, mc.thePlayer.posX + 10, mc.thePlayer.posY + 10, mc.thePlayer.posZ + 10));
			for(int i = 0; i < list.size(); ++i) {
				Entity e = (Entity)list.get(i);
				if(canBeAttacked(e)){
					((EntityClientPlayerMP)this).field_797_bg.addToSendQueue(new Packet7(0, e.field_620_ab, 1));
				}
			}
		}
		if(this.FC){
			this.Fly = true;
			this.noClip = true;
			((EntityClientPlayerMP)this).field_797_bg.addToSendQueue(new Packet0KeepAlive());
			this.mc.gameSettings.thirdPersonView = true;
		}
		else{
			this.noClip = false;
		}
		super.onLivingUpdate();
	}

	public void resetPlayerKeyState() {
		this.movementInput.resetKeyState();
	}

	public void handleKeyPress(int var1, boolean var2) {
		this.movementInput.checkKeyForMovementInput(var1, var2);
	}

	public void writeEntityToNBT(NBTTagCompound var1) {
		super.writeEntityToNBT(var1);
		var1.setInteger("Score", this.score);
	}

	public void readEntityFromNBT(NBTTagCompound var1) {
		super.readEntityFromNBT(var1);
		this.score = var1.getInteger("Score");
	}

	public void func_20059_m() {
		super.func_20059_m();
		this.mc.displayGuiScreen((GuiScreen)null);
	}

	public void displayGUIEditSign(TileEntitySign var1) {
		this.mc.displayGuiScreen(new GuiEditSign(var1));
	}

	public void displayGUIChest(IInventory var1) {
		this.mc.displayGuiScreen(new GuiChest(this.inventory, var1));
	}

	public void displayWorkbenchGUI(int var1, int var2, int var3) {
		this.mc.displayGuiScreen(new GuiCrafting(this.inventory, this.worldObj, var1, var2, var3));
	}

	public void displayGUIFurnace(TileEntityFurnace var1) {
		this.mc.displayGuiScreen(new GuiFurnace(this.inventory, var1));
	}

	public void onItemPickup(Entity var1, int var2) {
		this.mc.effectRenderer.func_1192_a(new EntityPickupFX(this.mc.theWorld, var1, this, -0.5F));
	}

	public int getPlayerArmorValue() {
		return this.inventory.getTotalArmorValue();
	}

	public void useCurrentItemOnEntity(Entity var1) {
		if(!var1.interact(this)) {
			ItemStack var2 = this.getCurrentEquippedItem();
			if(var2 != null && var1 instanceof EntityLiving) {
				var2.useItemOnEntity((EntityLiving)var1);
				if(var2.stackSize <= 0) {
					var2.func_1097_a(this);
					this.destroyCurrentEquippedItem();
				}
			}
		}

	}

	public void sendChatMessage(String var1) {
	}

	public void func_6420_o() {
	}

	public boolean isSneaking() {
		return this.movementInput.sneak;
	}

	public void setInPortal() {
		if(this.field_9373_b > 0) {
			this.field_9373_b = 10;
		} else {
			this.inPortal = true;
		}

	}

	public void setHealth(int var1) {
		int var2 = this.health - var1;
		if(var2 <= 0) {
			this.health = var1;
		} else {
			this.field_9346_af = var2;
			this.prevHealth = this.health;
			this.field_9306_bj = this.field_9366_o;
			this.damageEntity(var2);
			this.hurtTime = this.maxHurtTime = 10;
		}

	}

	public void respawnPlayer() {
		this.mc.respawn();
	}
}
